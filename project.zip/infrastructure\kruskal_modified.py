import json
import networkx as nx
import heapq

# --- Data Loading --- 
def load_json_data(file_path):
    """Loads data from a JSON file."""
    try:
        with open(file_path, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"Error: Data file not found at {file_path}")
        return None
    except json.JSONDecodeError:
        print(f"Error: Could not decode JSON from {file_path}")
        return None

def get_infrastructure_graph(road_data_path, facilities_data_path):
    """Constructs a graph from road and facility data."""
    road_data = load_json_data(road_data_path)
    facilities_data = load_json_data(facilities_data_path)

    if not road_data or not facilities_data:
        return None

    graph = nx.Graph() # Use Graph for MST

    # Add nodes from road_data (neighborhoods)
    if "nodes" in road_data:
        for node_info in road_data["nodes"]:
            node_id = str(node_info["ID"])
            graph.add_node(node_id, **node_info)
    
    # Add nodes from facilities_data
    for facility_info in facilities_data:
        facility_id = str(facility_info["ID"])
        if facility_id not in graph:
             graph.add_node(facility_id, **facility_info)
        else: # Update if already exists (e.g. if a facility ID matches a neighborhood ID)
            graph.nodes[facility_id].update(facility_info)

    # Add edges from road_data
    if "edges" in road_data:
        for edge_info in road_data["edges"]:
            u, v = str(edge_info["FromID"]), str(edge_info["ToID"])
            # Ensure nodes exist before adding edge
            if not graph.has_node(u):
                print(f"Warning: Node {u} not found, creating it for edge ({u}-{v}).")
                graph.add_node(u, ID=u, Name=f"Node {u}", Type="Unknown")
            if not graph.has_node(v):
                print(f"Warning: Node {v} not found, creating it for edge ({u}-{v}).")
                graph.add_node(v, ID=v, Name=f"Node {v}", Type="Unknown")
            
            attributes = {}
            if edge_info.get("status") == "existing":
                attributes["distance_km"] = float(edge_info.get("Distance_km", float("inf")))
                attributes["capacity_veh_hr"] = int(edge_info.get("Current_Capacity_vehicles_hour", 0))
                attributes["condition"] = int(edge_info.get("Condition_1_10", 0))
                attributes["type"] = "existing_road"
            elif edge_info.get("status") == "potential":
                attributes["distance_km"] = float(edge_info.get("Distance_km", float("inf")))
                attributes["cost_million_egp"] = float(edge_info.get("Construction_Cost_Million_EGP", float("inf")))
                attributes["potential_capacity_veh_hr"] = int(edge_info.get("Estimated_Capacity_vehicles_hour", 0))
                attributes["type"] = "potential_road"
            
            attributes["original_from_id"] = u
            attributes["original_to_id"] = v
            graph.add_edge(u, v, **attributes)
            
    return graph

# --- Kruskal's Algorithm (Modified) ---
def kruskal_mst_modified(graph, weight_key="distance_km", consider_potential_roads=False,
                         critical_facility_ids=None, high_population_threshold=0, 
                         population_weight_factor=0.1):
    """
    Finds a Minimum Spanning Tree using Kruskal's algorithm with modifications.
    Args:
        graph (nx.Graph): The input graph.
        weight_key (str): Edge attribute for weight (e.g., 'distance_km', 'cost_million_egp').
        consider_potential_roads (bool): If True, includes potential roads.
        critical_facility_ids (list): Node IDs for critical facilities to prioritize.
        high_population_threshold (int): Population count for high-population areas.
        population_weight_factor (float): Factor to reduce weight for prioritized connections (0 to 1).
    Returns:
        nx.Graph: The Minimum Spanning Tree.
    """
    if graph is None:
        return nx.Graph()

    mst = nx.Graph()
    mst.add_nodes_from(graph.nodes(data=True))
    
    edges = []
    for u, v, data in graph.edges(data=True):
        if not consider_potential_roads and data.get("type") == "potential_road":
            continue # Skip potential roads if not considered
        
        if data.get("type") == "potential_road" and weight_key == "distance_km" and "cost_million_egp" in data:
             # If using distance for potential roads, but cost is the primary attribute for them in MST context
             # This logic might need refinement based on how cost/distance are prioritized for potential roads
             # For now, if weight_key is distance, it will use distance. If cost, it will use cost.
             pass 

        if weight_key not in data:
            # print(f"Warning: Edge ({u}-{v}) missing weight '{weight_key}'. Assigning infinity.")
            original_weight = float("inf")
        else:
            original_weight = float(data[weight_key])

        modified_weight = original_weight

        # Apply prioritization
        is_critical_connection = False
        if critical_facility_ids:
            node_u_type = graph.nodes[u].get("Type")
            node_v_type = graph.nodes[v].get("Type")
            if (u in critical_facility_ids and node_u_type == "Medical") or \
               (v in critical_facility_ids and node_v_type == "Medical"): # Assuming 'Medical' type for facilities
                is_critical_connection = True
        
        u_pop = graph.nodes[u].get("Population", 0)
        v_pop = graph.nodes[v].get("Population", 0)
        is_high_pop_connection = (u_pop > high_population_threshold) or (v_pop > high_population_threshold)

        if is_critical_connection or is_high_pop_connection:
            modified_weight *= (1 - population_weight_factor)
        
        heapq.heappush(edges, (modified_weight, u, v, data))

    parent = {node: node for node in graph.nodes()}
    def find_set(node):
        if parent[node] == node:
            return node
        parent[node] = find_set(parent[node])
        return parent[node]

    def unite_sets(u_set, v_set):
        parent[u_set] = v_set

    num_edges_in_mst = 0
    target_num_edges = graph.number_of_nodes() - 1 # For a connected graph
    if graph.number_of_nodes() == 0:
        return mst
        
    # Handle disconnected graphs: build a spanning forest
    # Kruskal naturally handles this by adding edges as long as they don't form a cycle
    # within the same connected component.
    
    while edges and num_edges_in_mst < target_num_edges:
        weight, u, v, edge_data = heapq.heappop(edges)
        u_set, v_set = find_set(u), find_set(v)
        if u_set != v_set:
            mst.add_edge(u, v, **edge_data, modified_weight=weight, original_weight=edge_data.get(weight_key, float("inf")))
            unite_sets(u_set, v_set)
            num_edges_in_mst += 1
            if not nx.is_connected(mst) and num_edges_in_mst == target_num_edges : # if graph was disconnected
                 break # stop if we have enough edges for a spanning forest for all components
    
    # If the original graph was disconnected, target_num_edges might not be reached.
    # The loop condition `while edges` and `u_set != v_set` correctly builds a spanning forest.

    return mst

if __name__ == "__main__":
    print("Testing Kruskal Modified MST")
    base_path = r"c:\Users\abdoo\Desktop\transportation_system\data"
    road_data_file = base_path + r"\road_data.json"
    facilities_data_file = base_path + r"\facilities.json"

    infra_graph = get_infrastructure_graph(road_data_file, facilities_data_file)

    if infra_graph:
        print(f"Infrastructure graph loaded: {infra_graph.number_of_nodes()} nodes, {infra_graph.number_of_edges()} edges")
        
        # Test 1: Basic MST with distance on existing roads
        mst1 = kruskal_mst_modified(infra_graph, weight_key="distance_km", consider_potential_roads=False)
        if mst1.edges():
            total_dist1 = sum(d["distance_km"] for u,v,d in mst1.edges(data=True) if "distance_km" in d)
            print(f"MST 1 (Distance, Existing): {mst1.number_of_edges()} edges, Total Distance: {total_dist1:.2f} km")
        else:
            print("MST 1: No edges found.")

        # Test 2: MST with cost on potential roads, prioritizing critical facilities
        # Ensure 'cost_million_egp' is a valid weight_key for potential roads
        mst2 = kruskal_mst_modified(infra_graph, weight_key="cost_million_egp", 
                                    consider_potential_roads=True, 
                                    critical_facility_ids=["F9", "F10"], # Example facility IDs
                                    high_population_threshold=300000,
                                    population_weight_factor=0.2)
        if mst2.edges():
            total_cost2 = sum(d["cost_million_egp"] for u,v,d in mst2.edges(data=True) if "cost_million_egp" in d and d.get("type")=="potential_road")
            # Also sum distances for existing roads if they are part of this MST
            total_dist_existing_mst2 = sum(d["distance_km"] for u,v,d in mst2.edges(data=True) if "distance_km" in d and d.get("type")=="existing_road")
            print(f"MST 2 (Cost-Potential, Prioritized): {mst2.number_of_edges()} edges. Total Potential Cost: {total_cost2:.2f} M EGP. Total Existing Distance: {total_dist_existing_mst2:.2f} km")
        else:
            print("MST 2: No edges found.")
            
        # Test 3: MST with distance, including potential roads and prioritization
        mst3 = kruskal_mst_modified(infra_graph, weight_key="distance_km", 
                                    consider_potential_roads=True, 
                                    critical_facility_ids=["F9"], 
                                    high_population_threshold=200000,
                                    population_weight_factor=0.15)
        if mst3.edges():
            total_dist3 = sum(d["distance_km"] for u,v,d in mst3.edges(data=True) if "distance_km" in d)
            print(f"MST 3 (Distance, All Roads, Prioritized): {mst3.number_of_edges()} edges, Total Distance: {total_dist3:.2f} km")
        else:
            print("MST 3: No edges found.")
    else:
        print("Failed to load infrastructure graph for testing.")

