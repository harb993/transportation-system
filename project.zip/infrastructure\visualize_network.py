import json
import networkx as nx
import matplotlib.pyplot as plt

# --- Data Loading (shared with kruskal_modified.py, could be in a common util) ---
def load_json_data(file_path):
    """Loads data from a JSON file."""
    try:
        with open(file_path, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"Error: Data file not found at {file_path}")
        return None
    except json.JSONDecodeError:
        print(f"Error: Could not decode JSON from {file_path}")
        return None

def get_base_graph(road_data_path, facilities_data_path):
    """Constructs a base graph from road and facility data for visualization."""
    road_data = load_json_data(road_data_path)
    facilities_data = load_json_data(facilities_data_path)

    if not road_data or not facilities_data:
        print("Error loading data for graph construction.")
        return None

    graph = nx.Graph() # Using Graph for general visualization, can be DiGraph if direction is important

    # Add nodes from road_data (neighborhoods)
    if "nodes" in road_data:
        for node_info in road_data["nodes"]:
            node_id = str(node_info["ID"])
            graph.add_node(node_id, **node_info)
    
    # Add nodes from facilities_data
    for facility_info in facilities_data:
        facility_id = str(facility_info["ID"])
        if facility_id not in graph:
             graph.add_node(facility_id, **facility_info)
        else:
            graph.nodes[facility_id].update(facility_info)

    # Add edges from road_data
    if "edges" in road_data:
        for edge_info in road_data["edges"]:
            u, v = str(edge_info["FromID"]), str(edge_info["ToID"])
            if not graph.has_node(u):
                graph.add_node(u, ID=u, Name=f"Node {u}", Type="Unknown")
            if not graph.has_node(v):
                graph.add_node(v, ID=v, Name=f"Node {v}", Type="Unknown")
            
            attributes = {}
            if edge_info.get("status") == "existing":
                attributes["distance_km"] = float(edge_info.get("Distance_km", float("inf")))
                attributes["type"] = "existing_road"
            elif edge_info.get("status") == "potential":
                attributes["distance_km"] = float(edge_info.get("Distance_km", float("inf")))
                attributes["cost_million_egp"] = float(edge_info.get("Construction_Cost_Million_EGP", float("inf")))
                attributes["type"] = "potential_road"
            graph.add_edge(u, v, **attributes)
    return graph

# --- Network Visualization --- 
def visualize_network_graph(graph, highlight_edges=None, highlight_color="red", 
                            title="Transportation Network", output_path=None):
    """
    Visualizes the transportation network graph.
    Args:
        graph (nx.Graph): The graph to visualize.
        highlight_edges (list of tuples): Edges to highlight (e.g., MST edges).
        highlight_color (str): Color for highlighted edges.
        title (str): Plot title.
        output_path (str, optional): Path to save the visualization. If None, shows plot.
    Returns:
        matplotlib.figure.Figure: The figure object.
    """
    if graph is None or graph.number_of_nodes() == 0:
        print("Graph is empty or None, cannot visualize.")
        return None

    fig, ax = plt.subplots(figsize=(15, 12))
    pos = {}
    node_labels = {}
    node_colors = []
    node_types_seen = set()

    for node, data in graph.nodes(data=True):
        if "X_coordinate" in data and "Y_coordinate" in data:
            pos[node] = (data["X_coordinate"], data["Y_coordinate"])
        node_labels[node] = data.get("Name", node) # Use Name if available, else ID
        
        node_type = data.get("Type", "Unknown")
        node_types_seen.add(node_type)
        if node_type == "Residential":
            node_colors.append("lightblue")
        elif node_type == "Business":
            node_colors.append("lightgreen")
        elif node_type == "Mixed":
            node_colors.append("lightcoral")
        elif node_type == "Medical":
            node_colors.append("salmon")
        elif node_type == "Airport" or node_type == "Transit Hub":
            node_colors.append("gold")
        else:
            node_colors.append("lightgray")

    if not pos: # If no coordinates, use a layout algorithm
        pos = nx.spring_layout(graph, k=0.5, iterations=50)

    # Draw all edges
    nx.draw_networkx_edges(graph, pos, ax=ax, edge_color="gray", alpha=0.6, width=1.0)
    
    # Draw highlighted edges if any
    if highlight_edges:
        nx.draw_networkx_edges(graph, pos, ax=ax, edgelist=highlight_edges, 
                               edge_color=highlight_color, width=2.5)

    # Draw nodes
    nx.draw_networkx_nodes(graph, pos, ax=ax, node_color=node_colors, node_size=500, alpha=0.9)
    
    # Draw labels
    nx.draw_networkx_labels(graph, pos, ax=ax, labels=node_labels, font_size=8)

    plt.title(title, fontsize=16)
    plt.xlabel("X Coordinate (Longitude-like)")
    plt.ylabel("Y Coordinate (Latitude-like)")
    ax.tick_params(left=True, bottom=True, labelleft=True, labelbottom=True)
    
    # Create a legend for node types
    legend_elements = []
    color_map = {"Residential": "lightblue", "Business": "lightgreen", "Mixed": "lightcoral", 
                 "Medical": "salmon", "Airport": "gold", "Transit Hub": "gold", "Unknown": "lightgray"}
    
    # Only add legend items for types present in the graph
    for node_type in sorted(list(node_types_seen)):
        color = color_map.get(node_type, "lightgray")
        legend_elements.append(plt.Line2D([0], [0], marker="o", color="white", label=node_type, 
                                          markerfacecolor=color, markersize=10))
    
    ax.legend(handles=legend_elements, title="Node Types", loc="upper right")

    if output_path:
        plt.savefig(output_path)
        print(f"Visualization saved to {output_path}")
    else:
        plt.show()
        
    return fig

if __name__ == "__main__":
    print("Testing Network Visualization")
    base_path = r"c:\Users\abdoo\Desktop\transportation_system\data"
    road_data_file = base_path + r"\road_data.json"
    facilities_data_file = base_path + r"\facilities.json"
    output_viz_path = r"c:\Users\abdoo\Desktop\transportation_system\output\visualizations\infrastructure_network.png"
    
    # Ensure output directory exists
    import os
    os.makedirs(os.path.dirname(output_viz_path), exist_ok=True)

    main_graph = get_base_graph(road_data_file, facilities_data_file)

    if main_graph:
        print(f"Graph loaded for visualization: {main_graph.number_of_nodes()} nodes, {main_graph.number_of_edges()} edges")
        
        # Example: Visualize the full graph
        visualize_network_graph(main_graph, title="Full Infrastructure Network", output_path=output_viz_path)
        
        # Example: Visualize with some highlighted edges (e.g., a dummy path)
        # For a real scenario, these would come from an algorithm like MST or shortest path
        if main_graph.number_of_edges() > 5:
            dummy_highlight_path = list(main_graph.edges())[:5]
            visualize_network_graph(main_graph, highlight_edges=dummy_highlight_path, 
                                    title="Network with Highlighted Path Example", 
                                    output_path=output_viz_path.replace(".png", "_highlighted.png"))
    else:
        print("Failed to load graph for visualization testing.")

