import json
import networkx as nx

# --- Data Loading (shared, consider a common utility module later) ---
def load_json_data(file_path):
    """Loads data from a JSON file."""
    try:
        with open(file_path, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"Error: Data file not found at {file_path}")
        return None
    except json.JSONDecodeError:
        print(f"Error: Could not decode JSON from {file_path}")
        return None

def get_infrastructure_graph_for_cost(road_data_path, facilities_data_path):
    """Constructs a graph focusing on attributes relevant for cost analysis."""
    road_data = load_json_data(road_data_path)
    facilities_data = load_json_data(facilities_data_path) # Though facilities might not be directly costed here

    if not road_data:
        print("Error: Road data not found for cost analysis.")
        return None

    graph = nx.Graph()

    if "nodes" in road_data:
        for node_info in road_data["nodes"]:
            node_id = str(node_info["ID"])
            graph.add_node(node_id, **node_info)
    
    if facilities_data: # Add facility nodes as well
        for facility_info in facilities_data:
            facility_id = str(facility_info["ID"])
            if facility_id not in graph:
                graph.add_node(facility_id, **facility_info)
            else:
                graph.nodes[facility_id].update(facility_info)

    if "edges" in road_data:
        for edge_info in road_data["edges"]:
            u, v = str(edge_info["FromID"]), str(edge_info["ToID"])
            attributes = edge_info.copy()
            # Ensure numeric types for cost and distance if they exist
            if "Construction_Cost_Million_EGP" in attributes:
                attributes["Construction_Cost_Million_EGP"] = float(attributes["Construction_Cost_Million_EGP"])
            if "Distance_km" in attributes:
                attributes["Distance_km"] = float(attributes["Distance_km"])
            graph.add_edge(u, v, **attributes)
    return graph

# --- Cost Analysis Functions ---
def analyze_potential_road_costs(graph):
    """Analyzes and summarizes costs of potential new roads."""
    if graph is None:
        return {}

    potential_roads = []
    total_potential_cost = 0
    total_potential_distance = 0
    count = 0

    for u, v, data in graph.edges(data=True):
        if data.get("status") == "potential":
            cost = data.get("Construction_Cost_Million_EGP", 0)
            distance = data.get("Distance_km", 0)
            potential_roads.append({
                "from": u,
                "to": v,
                "cost_million_egp": cost,
                "distance_km": distance,
                "estimated_capacity": data.get("Estimated_Capacity_vehicles_hour")
            })
            total_potential_cost += cost
            total_potential_distance += distance
            count += 1
    
    return {
        "count": count,
        "total_potential_cost_million_egp": total_potential_cost,
        "average_potential_cost_million_egp": total_potential_cost / count if count > 0 else 0,
        "total_potential_distance_km": total_potential_distance,
        "average_potential_distance_km": total_potential_distance / count if count > 0 else 0,
        "potential_roads_list": sorted(potential_roads, key=lambda x: x["cost_million_egp"], reverse=True)
    }

def analyze_mst_cost(mst_graph, cost_attribute="cost_million_egp", distance_attribute="distance_km"):
    """Analyzes the cost and distance of a given MST or road selection."""
    if mst_graph is None or mst_graph.number_of_edges() == 0:
        return {"total_cost": 0, "total_distance": 0, "edge_count": 0, "details": []}

    total_cost = 0
    total_distance = 0
    edge_details = []

    for u, v, data in mst_graph.edges(data=True):
        current_cost = 0
        current_distance = 0
        road_type = data.get("type", "unknown")
        
        if road_type == "potential_road":
            current_cost = data.get(cost_attribute, 0)
        # For existing roads, construction cost is typically not relevant in MST cost analysis unless specified
        # but their distance is always relevant.
        current_distance = data.get(distance_attribute, 0)
        
        total_cost += current_cost
        total_distance += current_distance
        edge_details.append({
            "from": u, "to": v, 
            "cost": current_cost, 
            "distance": current_distance, 
            "type": road_type,
            "original_weight_used_for_mst": data.get("original_weight") # if available from kruskal_modified
        })

    return {
        "total_construction_cost_million_egp": total_cost, # Primarily from potential roads
        "total_network_distance_km": total_distance,
        "edge_count": mst_graph.number_of_edges(),
        "edge_details": edge_details
    }

if __name__ == "__main__":
    print("Testing Infrastructure Cost Analysis")
    base_path = r"c:\Users\abdoo\Desktop\transportation_system\data"
    road_data_file = base_path + r"\road_data.json"
    facilities_data_file = base_path + r"\facilities.json" # May not be used directly but good for consistency

    infra_graph = get_infrastructure_graph_for_cost(road_data_file, facilities_data_file)

    if infra_graph:
        print(f"Infrastructure graph loaded: {infra_graph.number_of_nodes()} nodes, {infra_graph.number_of_edges()} edges")
        
        # 1. Analyze costs of all potential roads
        potential_costs_summary = analyze_potential_road_costs(infra_graph)
        print("\n--- Potential Road Costs Summary ---")
        print(f"Number of potential road projects: {potential_costs_summary["count"]}")
        print(f"Total estimated cost: {potential_costs_summary["total_potential_cost_million_egp"]:.2f} M EGP")
        print(f"Average cost per project: {potential_costs_summary["average_potential_cost_million_egp"]:.2f} M EGP")
        print(f"Total distance of potential roads: {potential_costs_summary["total_potential_distance_km"]:.2f} km")
        if potential_costs_summary["count"] > 0:
            print("Top 3 most expensive potential roads:")
            for i, road in enumerate(potential_costs_summary["potential_roads_list"][:3]):
                print(f"  {i+1}. From {road["from"]} to {road["to"]}: {road["cost_million_egp"]} M EGP, {road["distance_km"]} km")

        # 2. Example: Analyze cost of a hypothetical MST (using kruskal_modified for a sample MST)
        # This requires importing from kruskal_modified or re-implementing MST logic here.
        # For simplicity, we will assume an MST is generated elsewhere and passed.
        # Here, we will create a dummy MST for testing analyze_mst_cost.
        
        # Create a small dummy MST from the infra_graph for testing purposes
        if infra_graph.number_of_edges() > 0:
            dummy_mst = nx.Graph()
            selected_edges = list(infra_graph.edges(data=True))[:max(1, infra_graph.number_of_nodes() // 2)] # take some edges
            for u,v,d in selected_edges:
                dummy_mst.add_node(u, **infra_graph.nodes[u])
                dummy_mst.add_node(v, **infra_graph.nodes[v])
                dummy_mst.add_edge(u,v,**d)
            
            if nx.is_connected(dummy_mst) or not dummy_mst.edges(): # if not connected, make it so for simple test
                 pass # if not connected, it will be a forest, analysis still works per edge
            
            mst_cost_summary = analyze_mst_cost(dummy_mst, cost_attribute="Construction_Cost_Million_EGP")
            print("\n--- Dummy MST Cost Summary ---")
            print(f"Number of edges in MST: {mst_cost_summary["edge_count"]}")
            print(f"Total construction cost (potential roads in MST): {mst_cost_summary["total_construction_cost_million_egp"]:.2f} M EGP")
            print(f"Total network distance of MST: {mst_cost_summary["total_network_distance_km"]:.2f} km")
    else:
        print("Failed to load infrastructure graph for cost analysis testing.")

